//
//  SecondViewController.swift
//  firebaseinst
//
//  Created by akademobi4 on 8.10.2018.
//  Copyright © 2018 enes. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseAuth
import FirebaseDatabase

class uploadVC: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    
    @IBOutlet weak var imageSelect: UIImageView!
    @IBOutlet weak var commentText: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        imageSelect.isUserInteractionEnabled = true
        let gestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(uploadVC.selectImage))
        imageSelect.addGestureRecognizer(gestureRecognizer)
    }
    
    @objc func selectImage() {
        let pickerController = UIImagePickerController()
        pickerController.delegate = self
        pickerController.sourceType = .photoLibrary
        pickerController.allowsEditing = true
        present(pickerController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        imageSelect.image = info[.originalImage] as? UIImage
        self.dismiss(animated: true, completion: nil)
    }


    
    
    
    @IBAction func postPressed(_ sender: Any) {
        let storage = Storage.storage()
        let storageRef = storage.reference()
        let mediaFolder = storageRef.child("media")
        if let data = imageSelect.image?.jpegData(compressionQuality: 0.5) {
            
            let uuid = NSUUID().uuidString
            
            let mediaImagesRef = mediaFolder.child("\(uuid)image.jpg")
            mediaImagesRef.putData(data, metadata: nil) { (metadata, error) in
                if error != nil {
                    let alert = UIAlertController(title: "hata", message: error?.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                    let okButton = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil)
                    alert.addAction(okButton)
                    self.present(alert, animated: true, completion: nil)
                } else {
                    mediaImagesRef.downloadURL(completion: { (url, error) in
                        if error == nil {
                            //database
                            
                            let imageURL = url?.absoluteString
                            
                            let databaseReference = Database.database().reference()
                            
                            let post = ["image" : imageURL!, "postedby" : Auth.auth().currentUser!.email!, "postText" : self.commentText.text!, "uuid" : uuid] as [String : Any]
                            databaseReference.child("users").child((Auth.auth().currentUser?.uid)!).child("post").childByAutoId().setValue(post)
                            
                            self.imageSelect.image = UIImage(named: "select.png")
                            self.commentText.text = ""
                            self.tabBarController?.selectedIndex = 0
                            
                        }
                    })
                }
            }
        }
        
    }
    
}

