//
//  feedCell.swift
//  firebaseinst
//
//  Created by akademobi4 on 30.10.2018.
//  Copyright © 2018 enes. All rights reserved.
//

import UIKit

class feedCell: UITableViewCell {

    @IBOutlet weak var userEmail: UILabel!
    @IBOutlet weak var userComment: UILabel!
    @IBOutlet weak var userImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
